<?php

namespace MyProject\Controllers;
use Apix\Request;
use Apix\Response;

/**
 * Hello
 *
 * Lets say hello to people nicely.
 *
 * @api_public  true
 * @api_version 1.0
 * @api_auth    groups=public
 */
class Hello {

    /**
     * Hello
     *
     * Say Hello to someone
     *
     * @param      string     $name        Who should we say hello to?
     * @return     array
     * @api_cache  ttl=60sec  tag=goodbye  Cache this call for 60 seconds
     */
    public function onRead(Request $request, $name) {
        if(strlen(trim($name)) == 0) {
            // Return a 400 if they didn't pass in a name
            throw new \Exception("I don't know who I'm saying hello to!", 400);
        }

        return array("greeting" => "hello, " . trim($name));
    }

    /**
     * Hello
     *
     * Say hello to someone using the POSTED greeting.
     *
     * @param      string     $name        Who should we say hello to?
     * @param      string     $greeting    How should we say hello?
     * @return     array
     * @api_cache  ttl=60sec  tag=goodbye  Cache this call for 60 seconds
     */
    public function onCreate(Request $request, $name) {
        if(strlen(trim($name)) == 0) {
            // Return a 400 if they didn't pass in a name
            throw new \Exception("I don't know who I'm saying hello to!", 400);
        }

        $data = $request->getBodyData();
        if($data == null || !is_array($data)) {
            // Return a 400 if they didn't pass in any POST data
            throw new \Exception("Could not read the POST request body", 400);
        }
        $greeting = array_key_exists('greeting', $data) ? (string) $data['greeting'] : "hello";

        return array("greeting" => $greeting . ', ' . trim($name));
    }
}

