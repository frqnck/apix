<?php

namespace MyProject\Controllers;
use Apix\Request;
use Apix\Response;

/**
 * Goodbye
 *
 * Lets say goodbye to people nicely.
 *
 * @api_public  true
 * @api_version 1.0
 * @api_auth    groups=public
 */
class Goodbye {

    /**
     * Goodbye
     *
     * Say Goodbye
     *
     * @param      string     $name        Who should we say goodbye to?
     * @return     array
     * @api_cache  ttl=60sec  tag=goodbye  Cache this call for 60 seconds
     */
    public function onRead(Request $request, $name) {
        if(strlen(trim($name)) == 0) {
            throw new \Exception("I don't know who I'm saying goodbye to!");
        }

        return array("goodbye" => "goodbye, " . trim($name));
    }
}

