<?php

require_once '../vendor/autoload.php';

try {

    $api = new Apix\Server(require '../config/config.php');
    echo $api->run();
} catch (\Exception $e) {
    header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500);
    die("<h1>500 Internal Server Error</h1>" . $e->getMessage());
}

