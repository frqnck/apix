<?php

return array(
    '/hello/:name' => array(
        'controller' => array(
            'name' => 'MyProject\Controllers\Hello',
            'args' => null
        )
    ),
    '/goodbye/:name' => array(
        'controller' => array(
            'name' => 'MyProject\Controllers\Goodbye',
            'args' => null
        )
    )
);

