<?php

use Apix\Cache;
use Apix\Service;

return array(
    // we'll reference the existing $config variable to retrieve our redis credentials
    'cache' => function() use ($config) {
        $redis = new \Redis();
        foreach($config['credentials']['redis']['servers'] as $redis_server) {
            $redis->connect($redis_server[0], $redis_server[1]);
        }
        $adapter = new Cache\Redis($redis, $config['credentials']['redis']['options']);

        // Reset this service definition so that continuous calls do not recreate a new adapter
        // but simply return the existing one.
        Service::set('cache', $adapter);
        return $adapter;
    }
);

