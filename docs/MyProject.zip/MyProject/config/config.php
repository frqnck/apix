<?php

define('DEBUG', true);

// Set our configuration variable to the default value
$config = require "../vendor/apix/apix/src/data/distribution/config.dist.php";
$config['api_version']     = '0.0.1.spamandeggs';
$config['api_realm']       = 'api.myproject.com';
$config['output_rootNode'] = 'myproject';

// We'll test this using Apache with no virtual hosts - so we'll have to redefine
// the routing path_prefix
$config['routing']['path_prefix'] = '/^\/MyProject\/public\/v(\d+)/i';

// Include credentials that we can use elsewhere in custom defined services, etc.
$config['credentials']     = require 'credentials.php';

// Include the resources we have defined in our resources.php configuration file
$config['resources']      += require 'resources.php';

// Include the services we have defined in our services.php configuration file.
// If a service is redefined in the services.php file, use that instead.
$config['services']       = array_merge($config['services'], require 'services.php');

// Include the plugins we have defined in our plugins.php configuration file
$config['plugins']        = array_merge($config['plugins'], require 'plugins.php');

return $config;

