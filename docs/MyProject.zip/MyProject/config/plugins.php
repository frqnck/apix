<?php

return array(
    // Plugin to cache the output of the controllers. The full Request-URI acts as
    // the unique cache id.  Caching is enabled through a controller method or closure's
    // annotation
    // e.g. * @api_cache  ttl=5mins  tags=tag1,tag2  flush=tag3,tag4
    'Apix\Plugin\Cache' => array('enable'=>false, 'adapter'=>$config['services']['cache'])
);

