<?php

return array(
    // use a Redis instance for caching
    'redis' => array(
        'servers' => array(
            array('kandel.infoc', 6379)
        ),
        'options' => array(
            'atomicity' => false,
            'serializer' => 'php'
        )
    )
);

